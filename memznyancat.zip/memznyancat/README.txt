1. Go to control panel search for Programs And Features Then Click Turn Windows Features On And Off
2. Look for the Telnet Client. When you find it install it by putting a check on it.
3. Put the music folder in C:
4. You are done!